﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NApp
{
    internal class ErrorHandling
    {
    }
}
