﻿using System;

namespace NApp
{
    public class Program
    {
        public static int Main(string[] args)
        {
            try
            {
                if (args.Length == 0)
                    return -1;
                else
                {
                    string parameter1 = args[0];
                    string parameter2 = args[1];
                    string parameter3 = args[2];
                    string parameter4 = args[3];
                    string parameter5 = args[4];
                   
                    

                    string connectionString = string.Empty;
                   
                    return 0;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error : {ex.Message} Detailed exception message: {ex}");
                return -1;
            }

        }
    }
}
